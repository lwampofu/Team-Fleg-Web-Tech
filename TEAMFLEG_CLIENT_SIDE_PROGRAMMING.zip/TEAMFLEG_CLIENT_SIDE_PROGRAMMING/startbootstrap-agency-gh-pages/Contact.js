function PrintResult(){
  var NAME = document.querySelector("#name").value;
  var EMAIL = document.querySelector("#email").value;
  var PHONE_NUMBER = document.querySelector("#phone").value;
  var MESSAGE = document.querySelector("#message").value;
  
  
  alert("NAME: " + NAME + "\n" +  "EMAIL: " + EMAIL + "\n" + "PHONE_NUMBER: " + PHONE_NUMBER + "\n" + "MESSAGE: " + MESSAGE);


}



